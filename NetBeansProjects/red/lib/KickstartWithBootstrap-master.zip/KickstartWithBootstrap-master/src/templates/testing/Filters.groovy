@artifact.package@import grails.test.mixin.Mock
import spock.lang.Specification

@Mock(@artifact.testclass@)
class @artifact.name@ extends Specification {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
    }
}